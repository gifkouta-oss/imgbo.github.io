//==SCRIPT SALDO & TEMA==//
const saldoEl = document.getElementById('saldo');
    const eyeOpen = document.getElementById('eyeOpen');
    const eyeClose = document.getElementById('eyeClose');
    const eyeBtn = document.getElementById('eyeBtn');
    const themeToggle = document.getElementById('themeToggle');
    
    // Saldo asli (angka) supaya mudah diformat
    const saldoValue = 1500;
    
    // Ambil status dari localStorage
    let saldoHidden = localStorage.getItem('topnetra_eye_hidden') === 'true';
    let theme = localStorage.getItem('topnetra_theme') || 'dark';
    
    // Set awal tema
    document.body.classList.toggle('light', theme === 'light');
    
    function updateSaldoDisplay() {
      if (saldoHidden) {
        saldoEl.textContent = '••••••';
        eyeOpen.style.display = 'none';
        eyeClose.style.display = 'block';
      } else {
        saldoEl.textContent = new Intl.NumberFormat('id-ID').format(saldoValue); // format ribuan
        eyeOpen.style.display = 'block';
        eyeClose.style.display = 'none';
      }
    }
    
    // Set awal saldo
    updateSaldoDisplay();
    
    // Event toggle saldo
    eyeBtn.addEventListener('click', () => {
      saldoHidden = !saldoHidden;
      localStorage.setItem('topnetra_eye_hidden', saldoHidden);
      updateSaldoDisplay();
    });
    
    // Event toggle tema
    themeToggle.addEventListener('click', () => {
      theme = (theme === 'dark') ? 'light' : 'dark';
      localStorage.setItem('topnetra_theme', theme);
      document.body.classList.toggle('light', theme === 'light');
    });
    
 //==SCRIPT PROMO KAPAN SAJA==//
 const track = document.getElementById('carouselTrack');
const dots = document.getElementById('dots');

const totalPages = track.children.length;

// Generate dots
for (let i = 0; i < totalPages; i++) {
  const dot = document.createElement("span");
  dot.classList.add("dot");
  if (i === 0) dot.classList.add("active");
  dots.appendChild(dot);
}

// Update dot on scroll
track.addEventListener('scroll', () => {
  const pageWidth = track.offsetWidth;
  const scrollLeft = track.scrollLeft;
  const pageIndex = Math.round(scrollLeft / pageWidth);
  
  const allDots = document.querySelectorAll('.dot');
  allDots.forEach(dot => dot.classList.remove('active'));
  if (allDots[pageIndex]) allDots[pageIndex].classList.add('active');
});


//==SCRIPT CEK PREMIUM==//
const storedLevel = localStorage.getItem("userLevel") || "{{nama_membership}}";
  const pesanDiv = document.getElementById("pesan");
  if (storedLevel.toLowerCase() === "premium") {
    pesanDiv.style.display = "none";
  }
